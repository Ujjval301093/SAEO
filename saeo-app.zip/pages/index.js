
export default function Home() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-3xl font-bold">Welcome to SAEO</h1>
      <p className="mt-2">A platform for farmers and buyers</p>
    </div>
  );
}
