# SAEO App

This is the MVP frontend for the SAEO farmer-buyer app.